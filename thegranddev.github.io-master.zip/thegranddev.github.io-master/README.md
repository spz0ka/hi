# thegranddev.github.io


Personal showcase website.
Yes, i know - github pages, of course as an actual showcase website ill be upgrading to a paid host but rn im very low on money

